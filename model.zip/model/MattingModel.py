import torch
import torch.nn as nn
import torchvision.models as models
from skimage import morphology
import torch.nn.functional as f
import numpy as np
from torch.nn.utils import spectral_norm as spectral_norm_fn
from torch.nn.utils import weight_norm as weight_norm_fn
class Pretrained_Vgg(nn.Module):
    def __init__(self):
        super(Pretrained_Vgg, self).__init__()
        vgg = models.vgg19(pretrained=True)
        #

        for p in vgg.parameters():
            p.requires_grad = False
        features = list(vgg.features.children())
        # print(features)
        self.conv1=nn.Sequential(*features[0:4])


    def forward(self,img1,img2):
        device = img1.device
        kernel_radius = 5
        F1 = self.conv1(img1)
        F3 = self.conv1(img2)
        dm_tensor ,f1_sf,f2_sf= self.fusion_channel_sf(F1,F3, kernel_radius=kernel_radius)#cpu
        f1_sf=torch.nn.Upsample(scale_factor=2, mode='bilinear')(f1_sf)
        f2_sf=torch.nn.Upsample(scale_factor=2, mode='bilinear')(f2_sf)
        dm_tensor  = torch.nn.Upsample(scale_factor=2, mode='bilinear')(dm_tensor)
        dm_sf=dm_tensor
        #trimap
        dm_np = dm_tensor.cpu().numpy()
        se = morphology.disk(kernel_radius)
        b, _, h, w = dm_tensor.shape
        for idx in range(b):
            buffer = dm_np[idx, 0, :, :]
            buffer = self.generate_trimap(buffer,se)
            dm_np[idx, 0, :, :] = buffer
        dm_tensor=torch.from_numpy(dm_np).float().to(device)

        return dm_tensor,dm_sf,f1_sf,f2_sf
        # return dm_tensor

    @staticmethod
    def generate_trimap(alpha,kernel):
        fg = np.array(np.equal(alpha, 1.0).astype(np.uint8))
        unknown = np.array(np.not_equal(alpha, 0.0).astype(np.uint8))
        unknown = morphology.dilation(unknown, kernel)
        trimap = fg+ (unknown - fg) * 0.5
        return trimap



    @staticmethod
    def fusion_channel_sf(f1, f2, kernel_radius=5):
        """
        Perform channel sf fusion two features
        """
        device = f1.device
        b, c, h, w = f1.shape
        r_shift_kernel = torch.FloatTensor([[0, 0, 0], [1, 0, 0], [0, 0, 0]]) \
            .cuda(device).reshape((1, 1, 3, 3)).repeat(c, 1, 1, 1)
        b_shift_kernel = torch.FloatTensor([[0, 1, 0], [0, 0, 0], [0, 0, 0]]) \
            .cuda(device).reshape((1, 1, 3, 3)).repeat(c, 1, 1, 1)
        f1_r_shift = f.conv2d(f1, r_shift_kernel, padding=1, groups=c)
        f1_b_shift = f.conv2d(f1, b_shift_kernel, padding=1, groups=c)
        f2_r_shift = f.conv2d(f2, r_shift_kernel, padding=1, groups=c)
        f2_b_shift = f.conv2d(f2, b_shift_kernel, padding=1, groups=c)
        f1_grad = torch.sqrt(torch.pow((f1_r_shift - f1), 2) + torch.pow((f1_b_shift - f1), 2))
        f2_grad = torch.sqrt(torch.pow((f2_r_shift - f2), 2) + torch.pow((f2_b_shift - f2), 2))
        kernel_size = kernel_radius * 2 + 1
        add_kernel = torch.ones((c, 1, kernel_size, kernel_size)).float().cuda(device)
        kernel_padding = kernel_size // 2
        f1_con=f.conv2d(f1_grad, add_kernel, padding=kernel_padding, groups=c)
        f2_con=f.conv2d(f2_grad, add_kernel, padding=kernel_padding, groups=c)
        f1_sf = torch.sum(f1_con, dim=1,keepdim=True)
        f2_sf = torch.sum(f2_con, dim=1,keepdim=True)
        weight_zeros = torch.zeros(f1_sf.shape).cuda(device)
        weight_ones = torch.ones(f1_sf.shape).cuda(device)
        dm_tensor = torch.where(f2_sf > f1_sf, weight_zeros, weight_ones).cuda(device)

        return dm_tensor, f1_sf, f2_sf



class ResnetBlock(nn.Module):
    def __init__(self, dim, dilation=1, use_spectral_norm=False):
        super(ResnetBlock, self).__init__()
        self.conv_block = nn.Sequential(
            nn.Conv2d(in_channels=dim, out_channels=dim, kernel_size=3, padding=dilation, dilation=dilation, bias=not use_spectral_norm),
            nn.InstanceNorm2d(dim, track_running_stats=False),
            nn.ReLU(True),
            nn.Conv2d(in_channels=dim, out_channels=dim, kernel_size=3, padding=1, dilation=1, bias=not use_spectral_norm),
            nn.InstanceNorm2d(dim, track_running_stats=False),
        )

    def forward(self, x):
        out = x + self.conv_block(x)
        return out



class BaseNetwork(nn.Module):
    def __init__(self):
        super(BaseNetwork, self).__init__()
    def init_weights(self, init_type='xavier', gain=0.02):
        '''
        initialize network's weights
        init_type: normal | xavier | kaiming | orthogonal
        https://github.com/junyanz/pytorch-CycleGAN-and-pix2pix/blob/9451e70673400885567d08a9e97ade2524c700d0/models/networks.py#L39
        '''

        def init_func(m):
            classname = m.__class__.__name__
            if hasattr(m, 'weight') and (classname.find('Conv') != -1 or classname.find('Linear') != -1):
                if init_type == 'normal':
                    nn.init.normal_(m.weight.data, 0.0, gain)
                elif init_type == 'xavier':
                    nn.init.xavier_normal_(m.weight.data, gain=gain)
                elif init_type == 'kaiming':
                    nn.init.kaiming_normal_(m.weight.data, a=0, mode='fan_in')
                elif init_type == 'orthogonal':
                    nn.init.orthogonal_(m.weight.data, gain=gain)

                if hasattr(m, 'bias') and m.bias is not None:
                    nn.init.constant_(m.bias.data, 0.0)

            elif classname.find('BatchNorm2d') != -1:
                nn.init.normal_(m.weight.data, 1.0, gain)
                nn.init.constant_(m.bias.data, 0.0)
        self.apply(init_func)


class EdgeGenerator(BaseNetwork):
    def __init__(self, residual_blocks=4, use_spectral_norm=True, init_weights=True):
        super(EdgeGenerator, self).__init__()

        self.encoder = nn.Sequential(
            nn.Conv2d(in_channels=2, out_channels=64, kernel_size=7, padding=3),
            nn.InstanceNorm2d(64, track_running_stats=False),
            nn.ReLU(True),
            nn.Conv2d(in_channels=64, out_channels=128, kernel_size=3, stride=2, padding=1),
            nn.InstanceNorm2d(128, track_running_stats=False),
            nn.ReLU(True),
            nn.Conv2d(in_channels=128, out_channels=256, kernel_size=3, stride=2, padding=1),
            nn.InstanceNorm2d(256, track_running_stats=False),
            nn.ReLU(True)
        )
        blocks = []
        for _ in range(residual_blocks):
            block = ResnetBlock(256, 2, use_spectral_norm=use_spectral_norm)
            blocks.append(block)
        self.middle=nn.Sequential(*blocks)

        self.decoder = nn.Sequential(
            nn.ConvTranspose2d(in_channels=256, out_channels=128, kernel_size=4, stride=2, padding=1),
            nn.InstanceNorm2d(128, track_running_stats=False),
            nn.ReLU(True),
            nn.ConvTranspose2d(in_channels=128, out_channels=64, kernel_size=4, stride=2, padding=1),
            nn.InstanceNorm2d(64, track_running_stats=False),
            nn.ReLU(True),
            nn.Conv2d(in_channels=64, out_channels=1, kernel_size=7, padding=3)
        )
        if init_weights:
            self.init_weights()

    def forward(self, x):
        x = self.encoder(x)
        x = self.middle(x)
        x = self.decoder(x)
        x = torch.sigmoid(x)
        return x

